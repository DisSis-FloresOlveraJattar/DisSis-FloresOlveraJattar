package pro;

import java.util.*;

/**
 * 
 */
public class CarritoCompra {

    /**
     * Default constructor
     */
    public CarritoCompra() {
    }

    /**
     * 
     */
    private Cliente cliente;

    /**
     * 
     */
    private Set<DetalleCompra> listaDetalleCompra;

    /**
     * 
     */
    public void CarritoCompra() {
        // TODO implement here
    }

    /**
     * @return
     */
    public Cliente getCliente() {
        // TODO implement here
        return null;
    }

    /**
     * @param cliente 
     * @return
     */
    public void setCliente(Cliente cliente) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<DetalleCompra> getListaDetalleCompra() {
        // TODO implement here
        return null;
    }

    /**
     * @param listaDetalleCompra 
     * @return
     */
    public void setListaDetalleCompra(Set<DetalleCompra> listaDetalleCompra) {
        // TODO implement here
        return null;
    }

    /**
     * @param producto 
     * @param cantidad 
     * @return
     */
    public void agregarProducto(Producto producto, int cantidad) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void mostrarPedido() {
        // TODO implement here
        return null;
    }

}