package pro;

import java.util.*;

/**
 * 
 */
public class Cliente {

    /**
     * Default constructor
     */
    public Cliente() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String correo;

    /**
     * 
     */
    private String direccion;

    /**
     * @param nombre 
     * @param correo 
     * @param direccion
     */
    public void Cliente(String nombre, String correo, String direccion) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getNombre() {
        // TODO implement here
        return "";
    }

    /**
     * @param nombre 
     * @return
     */
    public void setNombre(String nombre) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String getCorreo() {
        // TODO implement here
        return "";
    }

    /**
     * @param correo 
     * @return
     */
    public void setCorreo(String correo) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String getDireccion() {
        // TODO implement here
        return "";
    }

    /**
     * @param direccion 
     * @return
     */
    public void setDireccion(String direccion) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String toString() {
        // TODO implement here
        return "";
    }

}