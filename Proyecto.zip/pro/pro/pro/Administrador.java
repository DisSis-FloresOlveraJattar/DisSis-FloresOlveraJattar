package pro;

import java.util.*;

/**
 * 
 */
public class Administrador extends Cliente {

    /**
     * Default constructor
     */
    public Administrador() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String correo;

    /**
     * 
     */
    private String direccion;

    /**
     * @param nombre 
     * @param correo 
     * @param direccion
     */
    public void Administrador(String nombre, String correo, String direccion) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String toString() {
        // TODO implement here
        return "";
    }

}