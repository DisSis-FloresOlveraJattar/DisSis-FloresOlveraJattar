package pro;

import java.util.*;

/**
 * 
 */
public class Producto {

    /**
     * Default constructor
     */
    public Producto() {
    }

    /**
     * 
     */
    private String nombre;

    /**
     * 
     */
    private String codigo;

    /**
     * 
     */
    private double precio;

    /**
     * @param nombre 
     * @param codigo 
     * @param precio
     */
    public void Producto(String nombre, String codigo, double precio) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getNombre() {
        // TODO implement here
        return "";
    }

    /**
     * @param nombre 
     * @return
     */
    public void setNombre(String nombre) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String getCodigo() {
        // TODO implement here
        return "";
    }

    /**
     * @param codigo 
     * @return
     */
    public void setCodigo(String codigo) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public double getPrecio() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @param precio 
     * @return
     */
    public void setPrecio(double precio) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String toString() {
        // TODO implement here
        return "";
    }

}