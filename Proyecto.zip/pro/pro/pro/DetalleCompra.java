package pro;

import java.util.*;

/**
 * 
 */
public class DetalleCompra {

    /**
     * Default constructor
     */
    public DetalleCompra() {
    }

    /**
     * 
     */
    private int cantidad;

    /**
     * 
     */
    private double total;

    /**
     * 
     */
    private Producto producto;

    /**
     * @param producto 
     * @param cantidad
     */
    public void DetalleCompra(Producto producto, int cantidad) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Producto getProducto() {
        // TODO implement here
        return null;
    }

    /**
     * @param producto 
     * @return
     */
    public void setProducto(Producto producto) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public int getCantidad() {
        // TODO implement here
        return 0;
    }

    /**
     * @param cantidad 
     * @return
     */
    public void setCantidad(int cantidad) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public double getTotal() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @param total 
     * @return
     */
    public void setTotal(double total) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String toString() {
        // TODO implement here
        return "";
    }

}